top =
  let z1 = 4 in
  let z  = 3 in
  let y  = 2 in
  let x  = 1 in
  let z2 = 0 in
  if ((x + y) - (z + z2)) == 0 then y else x
